package AssistedPackage;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class AssisstedProject5
 */
@WebServlet("/FilterServlet")
public class FilterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FilterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // For demonstration purposes, check if username and password are valid
        if ("admin".equals(username) && "admin".equals(password)) {
            // Create a session
            HttpSession session = request.getSession(true);
            session.setAttribute("username", username);

            // Redirect to welcome page
            response.sendRedirect(request.getContextPath() + "/LoginFile.html");
        } else {
            // Redirect back to login page
            response.sendRedirect(request.getContextPath() + "/Filter.html");
        }
    }
}