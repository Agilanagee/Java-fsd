package test;

import java.util.List;

import Hibernate.Author;
import Hibernate.Book;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Project6 
{
	public static void main(String[] args)
	{
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        
        entityManager.getTransaction().begin();

        Author author = entityManager.find(Author.class, 1L);
        
        // At this point, books are not loaded yet
        System.out.println("Author: " + author.getName());
        
        // Lazy loading happens here when accessing the books collection
        List<Book> books = author.getBooks();
        for (Book book : books) {
            System.out.println("Book Title: " + book.getTitle());
        }

        entityManager.getTransaction().commit();
        entityManager.close();
        entityManagerFactory.close();
	}

}