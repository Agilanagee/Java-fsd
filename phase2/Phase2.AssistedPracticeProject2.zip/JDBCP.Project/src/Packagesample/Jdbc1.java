package Packagesample;

import java.sql.Connection;
import java.sql.DriverManager;

public class Jdbc1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conObj = DriverManager.getConnection("jdbc:mysql://localhost:3306/forest","root", "Strange@1983");
			if(conObj!=null)
				System.out.println("JDBC is Executed Successfully");
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}

	

}
