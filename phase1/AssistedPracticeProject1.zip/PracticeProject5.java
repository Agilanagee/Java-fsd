package phase1;

import java.util.*;

public class PracticeProject5 {
    public static void main(String[] args) {
        
        List<String> arrayList = new ArrayList<>();
        arrayList.add("Banglore");
        arrayList.add("Mumbai");
        arrayList.add("Chennai");
        System.out.println("ArrayList:");
        for (String fruit : arrayList) {
            System.out.println(fruit);
        }

        
        List<String> linkedList = new LinkedList<>();
        linkedList.add("Man");
        linkedList.add("Woman");
        linkedList.add("Children");
        System.out.println("\nLinkedList:");
        for (String color : linkedList) {
            System.out.println(color);
        }

       
        Set<String> hashSet = new HashSet<>();
        hashSet.add("Kapil Dev");
        hashSet.add("Rohit");
        hashSet.add("Dravid");
        System.out.println("\nHashSet:");
        for (String animal : hashSet) {
            System.out.println(animal);
        }

        
        Map<Integer, String> hashMap = new HashMap<>();
        hashMap.put(1, "One");
        hashMap.put(2, "Two");
        hashMap.put(3, "Three");
        System.out.println("\nHashMap:");
        for (Map.Entry<Integer, String> entry : hashMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
    }
}
