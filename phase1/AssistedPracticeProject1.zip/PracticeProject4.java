package phase1;

class MyClass {
    int num;
    String name;
    MyClass() {
        num = 0;
        name = "Default";
    }

    MyClass(int n, String s) {
        num = n;
        name = s;
    }

    MyClass(int n) {
        this(); 
        num = n;
    }

    MyClass(MyClass obj) {
        num = obj.num;
        name = obj.name;
    }


    void display() {
        System.out.println("Number: " + num + ", Name: " + name);
    }
}

public class PracticeProject4 
{
    public static void main(String[] args) {
       
        MyClass obj1 = new MyClass(); 
        MyClass obj2 = new MyClass(10, "Sam Curran"); 
        MyClass obj3 = new MyClass(20); 
        MyClass obj4 = new MyClass(obj2); 
       
        obj1.display();
        obj2.display();
        obj3.display();
        obj4.display();
    }
}
