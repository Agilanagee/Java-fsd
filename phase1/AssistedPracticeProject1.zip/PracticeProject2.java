package phase1;

public class PracticeProject2 { 
    public int publicVariable = 54;
    private int privateVariable = 66;
    protected int protectedVariable = 77;
    int defaultVariable = 82;
    public void publicMethod() {
        System.out.println("Public method called");
    }
    private void privateMethod() {
        System.out.println("Private method called");
    }  
    protected void protectedMethod() {
        System.out.println("Protected method called");
    }  
    void defaultMethod() {
        System.out.println("Default method called");
    }
    public static void main(String[] args) {
        PracticeProject2 example = new PracticeProject2();
        System.out.println("Public Variable: " + example.publicVariable);
        System.out.println("Protected Variable: " + example.protectedVariable);
        System.out.println("Default Variable: " + example.defaultVariable);
        example.publicMethod();
        example.protectedMethod();
        example.defaultMethod();
    }
}
