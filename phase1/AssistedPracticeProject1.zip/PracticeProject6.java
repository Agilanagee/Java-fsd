package phase1;
import java.util.*;

public class PracticeProject6 {
    public static void main(String[] args) {
        
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("Abdul", 22);
        hashMap.put("Ashwin", 27);
        hashMap.put("Henry", 45);
        System.out.println("HashMap:");
        for (Map.Entry<String, Integer> entry : hashMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }

        
        Map<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("Hockey", 1950);
        treeMap.put("Kabadi", 1992);
        treeMap.put("Cricket", 2011);
        System.out.println("\nTreeMap:");
        for (Map.Entry<String, Integer> entry : treeMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }

        
        Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
        linkedHashMap.put("Ronaldo", 39);
        linkedHashMap.put("Messi", 36);
        linkedHashMap.put("Neymer", 35);
        System.out.println("\nLinkedHashMap:");
        for (Map.Entry<String, Integer> entry : linkedHashMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
    }
}

