package phase1;

public class PracticeProject3 { 
    public void Main() {
        System.out.println("Method with no return value");
    }
    public int sub(int a, int b) {
        return a + b;
    }
    public void displayMessage(String N) {
        System.out.println(N);
    }

    public String getGreeting() {
        return "Return value with no parameters";
    }

    public static void main(String[] args) {
        PracticeProject3 s = new PracticeProject3();  
        s.Main();
        int sum = s.sub(15, 10);
        System.out.println("Sum: " + sum);
        s.displayMessage("Parameters with no retern value");
        String greeting = s.getGreeting();
        System.out.println("Greeting: " + greeting);
    }
}
