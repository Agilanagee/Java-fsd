package phase1;


public class PracticeProject7 { 
    private int outerVar = 150;
    private static int staticOuterVar = 200;  
    class InnerClass {
        void display() {
            System.out.println("Inner class method called");
            System.out.println("Outer variable accessed from inner class: " + outerVar);
            System.out.println("Static outer variable accessed from inner class: " + staticOuterVar);
        }
    }
    public static void main(String[] args) {
    	PracticeProject7  outer = new PracticeProject7 ();
        InnerClass inner = outer.new InnerClass();
        inner.display();
    }
}
