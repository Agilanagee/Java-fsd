package phase1;


import java.util.regex.*;

public class PracticeProject10 {
    public static void main(String[] args) {
        
        String pattern = "\\d+";
        
        
        String[] inputs = {"24689", "abc123", "123xyz", "384", "jkl"};

        
        Pattern regex = Pattern.compile(pattern);
        
        
        for (String input : inputs) {
            Matcher matcher = regex.matcher(input);
            if (matcher.matches()) {
                System.out.println("'" + input + "' matches the pattern.");
            } else {
                System.out.println("'" + input + "' does not match the pattern.");
            }
        }
    }
}
