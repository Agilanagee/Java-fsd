package phase1;

public class PracticeProject29 {
    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i; 
            }
        }
        return -1; 
    }

    public static void main(String[] args) {
        int[] arr = {18, 10, 7, 45, 99};
        int target = 45;
        int result = linearSearch(arr, target);
        if (result != -1) {
            System.out.println("Index of the Element found: " + result);
        } else {
            System.out.println("Element not found in array");
        }
    }
}
