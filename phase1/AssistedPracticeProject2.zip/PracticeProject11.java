package phase1;

import phase1.MyRunnable;
import phase1.MyThread;

class MyThread extends Thread {
	public void run() {
		System.out.println("Thread created by extending Thread class.");
	}
}

//Thread by implementing Runnable interface
class MyRunnable implements Runnable {
	public void run() {
		System.out.println("Thread created by implementing Runnable interface.");
	}
}

public class PracticeProject11 {

	public static void main(String[] args) {
		// Creating and starting thread by extending thread class
		MyThread thr1 = new MyThread();
		thr1.start();

		// Creating and starting thread by implementing Runnable interface
		MyRunnable myRunnable = new MyRunnable();
		Thread thr2 = new Thread(myRunnable);
		thr2.start();
	}
}
