package phase1;

class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class PracticeProject15 {
    public static void main(String[] args) {
        try {
            int result = divide(10, 0);
            System.out.println("Result of division: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero is not allowed.");
        } catch (CustomException e) {
            System.out.println("Custom Exception caught: " + e.getMessage());
        } finally {
            System.out.println("Inside finally block.");
        }
    }

    public static int divide(int a, int b) throws CustomException {
        if (b == 0) {
            throw new CustomException("Division by zero is not allowed.");
        }
        return a / b;
    }
}