package phase1;

interface A {
    default void display() {
        System.out.println("A's display method");
    }
}

interface B extends A {
    default void display() {
        System.out.println("B's display method");
    }
}

interface C extends A {
    default void display() {
        System.out.println("C's display method");
    }
}


class D implements B, C {
    
    public void display() {
        B.super.display();
        C.super.display(); 
    }
}

public class PracticeProject19 {
    public static void main(String[] args) {
        D obj = new D();
        obj.display();
    }
}

