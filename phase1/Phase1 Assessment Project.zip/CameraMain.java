package CameraRentalApplication;

import java.util.Scanner;

public class CameraMain {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("+----------------------------------------+");
		System.out.println("|      WELCOME TO CAMERA-RENTAL-APP      |");
		System.out.println("|        The World through Lenses        |");
		System.out.println("+----------------------------------------+");
		System.out.println("PLEASE LOGIN TO CONTINUE");
		System.out.println("USERNAME ");
		String s1 = scanner.nextLine();
		System.out.println("PASSWORD ");
		String s2 = scanner.nextLine();

		CameraRent rentalCams = new CameraRent();
		rentalCams.addcamera(new Camera("SAMSUNG  ", "SM22",2000));
		rentalCams.addcamera(new Camera("Sony     ", "B8 III ",1800));
		rentalCams.addcamera(new Camera("SAMSUNG  ", "DS163  ",2300));
		rentalCams.addcamera(new Camera("Canon    ", "EOS R3 ",4000));
		rentalCams.addcamera(new Camera("SONY     ", "DSLR",1100));
		rentalCams.addcamera(new Camera("Panasonic", "MINI 80",10350));
		rentalCams.addcamera(new Camera("NIKON    ", "DIGI G7",1700));
		rentalCams.addcamera(new Camera("SONY     ", "CT",5000));
		rentalCams.addcamera(new Camera("Panasonic", "HD     ",4500));
		rentalCams.addcamera(new Camera("SAMSUNG  ", "ModelX2",2800));
		rentalCams.addcamera(new Camera("LG       ", "ModelX1", 13000));
		rentalCams.addcamera(new Camera("SONY     ", "HD-212 ",  9000));
		
		while (true) {
			System.out.println("1.MY CAMERA");
			System.out.println("2.RENT A CAMERA");
			System.out.println("3.VIEW ALL CAMERAS");
			System.out.println("4.MY WALLET");
			System.out.println("5.EXIT");
			System.out.print("Select choice: ");

			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("1.ADD");
				System.out.println("2.REMOVE");
				System.out.println("3.VIEW MY CAMERAS");
				System.out.println("4.GO TO PREVIOUS MENU");
				int st = scanner.nextInt();
				switch (st) {
				case 1:
					System.out.print("Enter new camera brand: ");

					String brand = scanner.next();
					System.out.print("Enter new camera model: ");
					String model = scanner.next();
					System.out.print("Enter the rental amount per-day: ");
					double rentalAmount = scanner.nextDouble();
					rentalCams.addcamera(new Camera(brand, model, rentalAmount));
					System.out.println("New camera details added successfully.");

					break;
				case 2:
					rentalCams.displayAvailableCameras();
					System.out.println("Enter the camera ID to remove - ");
					int id = scanner.nextInt();
					rentalCams.removeCamera(id);
					break;
				case 3:
					rentalCams.displayAvailableCameras();
					
				case 4:
					break;

				}
				break;
			case 2:
				System.out.println("FOLLOWING IS THE LIST OF AVAILABLE CAMERAS");
				rentalCams.displayAvailableCameras();
				System.out.print("Enter the number of the camera you want to rent: ");
				int CameraIndex = scanner.nextInt();
				rentalCams.rentCamera(CameraIndex);
				break;

			case 3:
				rentalCams.displayAvailableCameras();
				break;
			case 4:
				double balance = rentalCams.checkWalletBalance();
				System.out.println("Current wallet balance: " + balance);
				System.out.println("DO YOU WANT TO DEPOSIT MORE AMOUNT TO YOUR WALLET ?(1.YES 2.NO)");
				int ans = scanner.nextInt();
				if (ans == 1) {
					System.out.print("Enter the amount to deposit: ");
					double depositAmount = scanner.nextDouble();
					rentalCams.depositMoney(depositAmount);
				}
				break;
			case 5:
				System.out.println("THANKS FOR USING THIS SITE");
				System.exit(0);
				break;
			default:
				System.out.println("Your choice is Invalid,try again!");
				break;
			}
		}
	}

}
