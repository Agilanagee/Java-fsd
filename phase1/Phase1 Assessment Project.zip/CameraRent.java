package CameraRentalApplication;

import java.util.ArrayList;
import java.util.List;

public class CameraRent {

	private List<Camera> availableCameras;
	private Wallet userWallet;

	public CameraRent() {

		availableCameras = new ArrayList<>();
		userWallet = new Wallet();
	}

	public void addcamera(Camera Camera) {
		availableCameras.add(Camera);
	}

	public void removeCamera(int CameraIndex) {
		if (CameraIndex >= 1 && CameraIndex <= availableCameras.size()) {
			availableCameras.remove(CameraIndex - 1);
			System.out.println("Removed the selected Camera successfully.");
		} else {
			System.out.println("Camera selection is Invalid!");
		}
	}

	public void displayAvailableCameras() {
		if (availableCameras.isEmpty()) {
			System.out.println("No Camera Data available");
		} else {
			System.out.println("Available Cameras:");
			System.out.println(" 	");
			System.out.println(" 	");
			for (int i = 0; i < availableCameras.size(); i++) {
				Camera Camera = availableCameras.get(i);

				System.out.println((i + 1) + ".	Brand: " + Camera.getBrand() + "	Model: " + Camera.getModel()
						+ "	Rental Amount: $" + Camera.getRentalAmount() + "	per day " + checkAvailability(Camera));
			}
			System.out.println(" 	");
			System.out.println(" 	");
		}
	}

	private String checkAvailability(Camera Camera) {

		return Camera.isRented() ? "Rented" : "availavle";
	}

	public void rentCamera(int CameraIndex) {
		if (CameraIndex >= 1 && CameraIndex <= availableCameras.size()) {
			Camera selectedCamera = availableCameras.get(CameraIndex - 1);
			if (userWallet.getBalance() >= selectedCamera.getRentalAmount()) {
				userWallet.setBalance(userWallet.getBalance() - selectedCamera.getRentalAmount());
				selectedCamera.setRented(true);
				System.out.println("Rented the Camera successfully!");
			} else {
				System.out.println("Your Wallet Amount is Insufficient. Deposit money immediately.");
			}
		} else {
			System.out.println("Camera selection is Invalid!");
		}

	}

	public void depositMoney(double amount) {
		userWallet.deposit(amount);
		System.out.println("Amount Deposited successful. Current wallet balance: $" + userWallet.getBalance());
	}

	public double checkWalletBalance() {
		return userWallet.getBalance();
	}

}

