package phase1;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class Practiceproject24 {
    Node head;

 
    void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

   
    void delete(int key) {
        Node prev = null;
        Node current = head;

 
        if (current != null && current.data == key) {
            head = current.next;
            return;
        }

       
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        // If the key is not present in the list
        if (current == null) {
            System.out.println("Key not found in the list.");
            return;
        }

     
        prev.next = current.next;
    }

    void display() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }

        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Practiceproject24 list = new Practiceproject24();
        list.insert(1);
        list.insert(2);
        list.insert(3);
        list.insert(4);
        list.insert(5);

        System.out.println("Original List:");
        list.display();

       
        list.delete(3);
        System.out.println("List after deleting first occurrence of key 3:");
        list.display();
    }
}

