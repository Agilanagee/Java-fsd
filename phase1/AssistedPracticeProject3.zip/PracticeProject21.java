package phase1;

import java.util.Arrays;

public class PracticeProject21 {
    public static void main(String[] args) {
        int[] arr = {10, 5, 3, 9, 12, 7, 2, 8, 1, 6};

        int fourthSmallest = findFourthSmallest(arr);

        System.out.println("The fourth smallest element is: " + fourthSmallest);
    }

    
    public static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            System.out.println("Array length is less than 4.");
            return -1;
        }
        Arrays.sort(arr);
        return arr[3];
    }
}

