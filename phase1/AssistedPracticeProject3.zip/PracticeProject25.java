package phase1;

import java.util.Scanner;

class Node1 {

    int data;
    Node1 next;

    Node1(int data) {

        this.data = data;

        this.next = null;

    }
}

public class PracticeProject25 {

    Node1 head;

    PracticeProject25() {

        head = null;

    }
    void insert(int data) {

        Node1 newNode = new Node1(data);


        if (head == null) {

            head = newNode;

            head.next = head;

            return;

        }
        if (data < head.data) {

            newNode.next = head;

            Node1 current = head;

            while (current.next != head) {

                current = current.next;

            }

            current.next = newNode;

            head = newNode;

            return;

        }
        Node1 current = head;

        while (current.next != head && current.next.data < data) {

            current = current.next;

        }
        newNode.next = current.next;

        current.next = newNode;

    }
    void display() {

        if (head == null) {

            System.out.println("Circular linked list is empty.");

            return;

        }
        Node1 current = head;

        do {

            System.out.print(current.data + " ");

            current = current.next;

        } while (current != head);

        System.out.println();
    }



    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        PracticeProject25 list = new PracticeProject25();



        System.out.print("Enter the number of elements to be inserted: ");

        int n = scanner.nextInt();



        System.out.println("Enter the elements to be inserted into the sorted circular linked list:");

        for (int i = 0; i < n; i++) {

            int data = scanner.nextInt();

            list.insert(data);

        }



        System.out.println("Sorted Circular Linked List:");

        list.display();

        scanner.close();

    }

}
