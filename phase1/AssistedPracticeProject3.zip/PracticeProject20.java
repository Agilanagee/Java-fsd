package phase1;

public class PracticeProject20 {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int rotateSteps = 5; 

        System.out.println("Original Array:");
        displayArray(array);

        rightRotateArray(array, rotateSteps);

        System.out.println("\nArray after right rotation by " + rotateSteps + " steps:");
        displayArray(array);
    }


    public static void rightRotateArray(int[] arr, int steps) {
        int n = arr.length;
        steps = steps % n; 

   
        int[] temp = new int[steps];
        for (int i = 0; i < steps; i++) {
            temp[i] = arr[n - steps + i];
        }
        for (int i = n - 1; i >= steps; i--) {
            arr[i] = arr[i - steps];
        }
        for (int i = 0; i < steps; i++) {
            arr[i] = temp[i];
        }
    }

    public static void displayArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}

