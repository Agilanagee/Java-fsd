package phase1;

import java.util.LinkedList;
import java.util.Queue;

public class PracticeProject28 {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        // Insert elements into the queue
        System.out.println("Enqueuing elements into the queue:");
        queue.add(20);
        queue.add(22);
        queue.add(33);
        queue.add(45);
        queue.add(54);

        
        System.out.println("Queue elements: " + queue);

        
        System.out.println("\nDequeuing elements from the queue:");
        while (!queue.isEmpty()) {
            int removedElement = queue.poll();
            System.out.println("Dequeued element: " + removedElement);
        }

       
        if (queue.isEmpty()) {
            System.out.println("\nThe queue is empty now.");
        } else {
            System.out.println("\nThe queue is not empty.");
        }
    }
}

