package phase1;

import java.util.Scanner;

class ListNode2 {

	int val;
	ListNode2 prev;
	ListNode2 next;
	
	ListNode2(int val) {
		this.val = val;
		this.prev = null;
		this.next = null;

	}
}
public class PracticeProject26 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		ListNode2 head = null;

		ListNode2 tail = null;
		System.out.println("Enter elements to create the doubly linked list (enter -1 to stop):");

		int val = scanner.nextInt();

		while (val != -1) {

			ListNode2 newNode = new ListNode2(val);

			if (head == null) {

				head = newNode;

				tail = newNode;

			} else {

				tail.next = newNode;

				newNode.prev = tail;

				tail = newNode;

			}

			val = scanner.nextInt();

		}
		System.out.println("Forward traversal:");

		ListNode2 current = head;

		while (current != null) {

			System.out.print(current.val + " ");

			current = current.next;

		}
		System.out.println("\nBackward traversal:");

		current = tail;

		while (current != null) {

			System.out.print(current.val + " ");

			current = current.prev;
		}		

	}
}
