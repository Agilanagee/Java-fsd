package com.apps;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bean.Employee;



public class Project1 {
	public static void main(String[] args) {
		ApplicationContext ac = new ClassPathXmlApplicationContext("Project1.xml");
		Employee emp = (Employee)ac.getBean("empobj");
		
		
		System.out.println("Emp No : " + emp.getEmpno());
		System.out.println("Emp Name : " + emp.getEname());
		System.out.println("Emp Job : " + emp.getJob());
		System.out.println("Emp Salary : " + emp.getSalary());
	}

}
